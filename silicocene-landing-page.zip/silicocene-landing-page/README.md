# Silicocene Landing Page

A Pen created on CodePen.

Original URL: [https://codepen.io/LeoHanglami/pen/bNVRvoK](https://codepen.io/LeoHanglami/pen/bNVRvoK).

